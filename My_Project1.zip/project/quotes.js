// Curated collection of comforting, literary, and mystical quotes
export const quotes = [
    {
        text: "The universe is not only stranger than we imagine, it is stranger than we can imagine.",
        author: "J.B.S. Haldane",
        category: "cosmic"
    },
    {
        text: "We are all made of star stuff. We are a way for the cosmos to know itself.",
        author: "Carl Sagan",
        category: "cosmic"
    },
    {
        text: "In the depth of winter, I finally learned that there was in me an invincible summer.",
        author: "Albert Camus",
        category: "literary"
    },
    {
        text: "The only way to deal with an unfree world is to become so absolutely free that your very existence is an act of rebellion.",
        author: "Albert Camus",
        category: "philosophical"
    },
    {
        text: "I have loved the stars too fondly to be fearful of the night.",
        author: "Sarah Williams",
        category: "cosmic"
    },
    {
        text: "What we know is a drop, what we don't know is an ocean.",
        author: "Isaac Newton",
        category: "wisdom"
    },
    {
        text: "The wound is the place where the Light enters you.",
        author: "Rumi",
        category: "mystical"
    },
    {
        text: "Yesterday I was clever, so I wanted to change the world. Today I am wise, so I am changing myself.",
        author: "Rumi",
        category: "wisdom"
    },
    {
        text: "Do not go gentle into that good night. Rage, rage against the dying of the light.",
        author: "Dylan Thomas",
        category: "literary"
    },
    {
        text: "The most beautiful thing we can experience is the mysterious.",
        author: "Albert Einstein",
        category: "mystical"
    },
    {
        text: "Books are a uniquely portable magic.",
        author: "Stephen King",
        category: "literary"
    },
    {
        text: "I am not afraid of storms, for I am learning how to sail my ship.",
        author: "Louisa May Alcott",
        category: "courage"
    },
    {
        text: "The future belongs to those who believe in the beauty of their dreams.",
        author: "Eleanor Roosevelt",
        category: "dreams"
    },
    {
        text: "We accept the love we think we deserve.",
        author: "Stephen Chbosky",
        category: "love"
    },
    {
        text: "It is during our darkest moments that we must focus to see the light.",
        author: "Aristotle",
        category: "hope"
    },
    {
        text: "The only impossible journey is the one you never begin.",
        author: "Tony Robbins",
        category: "courage"
    },
    {
        text: "In the midst of chaos, there is also opportunity.",
        author: "Sun Tzu",
        category: "wisdom"
    },
    {
        text: "The best time to plant a tree was 20 years ago. The second best time is now.",
        author: "Chinese Proverb",
        category: "wisdom"
    },
    {
        text: "Magic is believing in yourself. If you can do that, you can make anything happen.",
        author: "Johann Wolfgang von Goethe",
        category: "mystical"
    },
    {
        text: "Not all those who wander are lost.",
        author: "J.R.R. Tolkien",
        category: "literary"
    },
    {
        text: "The nights are long, but the years are short.",
        author: "Anonymous",
        category: "time"
    },
    {
        text: "There is another world, but it is in this one.",
        author: "W.B. Yeats",
        category: "mystical"
    },
    {
        text: "We are all in the gutter, but some of us are looking at the stars.",
        author: "Oscar Wilde",
        category: "hope"
    },
    {
        text: "Be yourself; everyone else is already taken.",
        author: "Oscar Wilde",
        category: "authenticity"
    },
    {
        text: "Two things are infinite: the universe and human stupidity; and I'm not sure about the universe.",
        author: "Albert Einstein",
        category: "humor"
    },
    {
        text: "So many books, so little time.",
        author: "Frank Zappa",
        category: "literary"
    },
    {
        text: "A room without books is like a body without a soul.",
        author: "Marcus Tullius Cicero",
        category: "literary"
    },
    {
        text: "The opposite of love is not hate, it's indifference.",
        author: "Elie Wiesel",
        category: "love"
    },
    {
        text: "It is never too late to be what you might have been.",
        author: "George Eliot",
        category: "potential"
    },
    {
        text: "There are only two ways to live your life. One is as though nothing is a miracle. The other is as though everything is a miracle.",
        author: "Albert Einstein",
        category: "mystical"
    },
    {
        text: "The person, be it gentleman or lady, who has not pleasure in a good novel, must be intolerably stupid.",
        author: "Jane Austen",
        category: "literary"
    },
    {
        text: "Good friends, good books, and a sleepy conscience: this is the ideal life.",
        author: "Mark Twain",
        category: "contentment"
    },
    {
        text: "Life is too important to be taken seriously.",
        author: "Oscar Wilde",
        category: "humor"
    },
    {
        text: "You may say I'm a dreamer, but I'm not the only one.",
        author: "John Lennon",
        category: "dreams"
    },
    {
        text: "It is better to be hated for what you are than to be loved for what you are not.",
        author: "André Gide",
        category: "authenticity"
    },
    {
        text: "When one door of happiness closes, another opens.",
        author: "Helen Keller",
        category: "hope"
    },
    {
        text: "Everything you've ever wanted is on the other side of fear.",
        author: "George Addair",
        category: "courage"
    },
    {
        text: "It is impossible to live without failing at something, unless you live so cautiously that you might as well not have lived at all.",
        author: "J.K. Rowling",
        category: "courage"
    },
    {
        text: "Remember that not getting what you want is sometimes a wonderful stroke of luck.",
        author: "Dalai Lama",
        category: "wisdom"
    },
    {
        text: "The journey of a thousand miles begins with one step.",
        author: "Lao Tzu",
        category: "journey"
    },
    {
        text: "That which does not kill us makes us stronger.",
        author: "Friedrich Nietzsche",
        category: "resilience"
    },
    {
        text: "Life is really simple, but we insist on making it complicated.",
        author: "Confucius",
        category: "simplicity"
    },
    {
        text: "The unexamined life is not worth living.",
        author: "Socrates",
        category: "wisdom"
    },
    {
        text: "Turn your wounds into wisdom.",
        author: "Oprah Winfrey",
        category: "healing"
    },
    {
        text: "The only true wisdom is in knowing you know nothing.",
        author: "Socrates",
        category: "wisdom"
    },
    {
        text: "In three words I can sum up everything I've learned about life: it goes on.",
        author: "Robert Frost",
        category: "resilience"
    },
    {
        text: "To live is the rarest thing in the world. Most people just exist.",
        author: "Oscar Wilde",
        category: "living"
    },
    {
        text: "I've learned that people will forget what you said, people will forget what you did, but people will never forget how you made them feel.",
        author: "Maya Angelou",
        category: "impact"
    },
    {
        text: "Whether you think you can or you think you can't, you're right.",
        author: "Henry Ford",
        category: "mindset"
    },
    {
        text: "If you want to lift yourself up, lift up someone else.",
        author: "Booker T. Washington",
        category: "service"
    },
    {
        text: "The best revenge is massive success.",
        author: "Frank Sinatra",
        category: "success"
    },
    {
        text: "Education is the most powerful weapon which you can use to change the world.",
        author: "Nelson Mandela",
        category: "education"
    },
    {
        text: "The most courageous act is still to think for yourself. Aloud.",
        author: "Coco Chanel",
        category: "courage"
    },
    {
        text: "Life shrinks or expands in proportion to one's courage.",
        author: "Anaïs Nin",
        category: "courage"
    },
    {
        text: "The moon does not fight. It attacks no one. It does not worry. It does not try to crush others. It keeps to its course, but by its very nature, it gently influences.",
        author: "Ming-Dao Deng",
        category: "mystical"
    },
    {
        text: "She was a wild one; always stomping on eggshells that everyone else tiptoed on.",
        author: "Kaitlin Foster",
        category: "wildness"
    },
    {
        text: "The witch knows nothing in this world is supernatural. It is all natural.",
        author: "Laurie Cabot",
        category: "mystical"
    },
    {
        text: "Magic exists. Who can doubt it, when there are rainbows and wildflowers, the music of the wind and the silence of the stars?",
        author: "Nora Roberts",
        category: "mystical"
    },
    {
        text: "She believed she could, so she did.",
        author: "R.S. Grey",
        category: "empowerment"
    },
    {
        text: "The cave you fear to enter holds the treasure you seek.",
        author: "Joseph Campbell",
        category: "courage"
    },
    {
        text: "Stars can't shine without darkness.",
        author: "D.H. Sidebottom",
        category: "hope"
    },
    {
        text: "She is clothed with strength and dignity, and she laughs without fear of the future.",
        author: "Proverbs 31:25",
        category: "strength"
    },
    {
        text: "The universe is under no obligation to make sense to you.",
        author: "Neil deGrasse Tyson",
        category: "cosmic"
    },
    {
        text: "In the end, we will remember not the words of our enemies, but the silence of our friends.",
        author: "Martin Luther King Jr.",
        category: "friendship"
    },
    {
        text: "A witch ought never to be frightened in the darkest forest because she should be sure in her soul that the most terrifying thing in the forest was her.",
        author: "Terry Pratchett",
        category: "mystical"
    },
    {
        text: "The real question is not whether life exists after death. The real question is whether you are alive before death.",
        author: "Osho",
        category: "living"
    },
    {
        text: "She remembered who she was and the game changed.",
        author: "Lalah Delia",
        category: "empowerment"
    },
    {
        text: "Trust the magic of new beginnings.",
        author: "Meister Eckhart",
        category: "mystical"
    },
    {
        text: "The night is darkest just before the dawn.",
        author: "Thomas Fuller",
        category: "hope"
    },
    {
        text: "What lies behind us and what lies before us are tiny matters compared to what lies within us.",
        author: "Ralph Waldo Emerson",
        category: "inner strength"
    },
    {
        text: "She was powerful not because she wasn't scared but because she went on so strongly, despite the fear.",
        author: "Atticus",
        category: "courage"
    },
    {
        text: "The cosmos is within us. We are made of star-stuff.",
        author: "Carl Sagan",
        category: "cosmic"
    },
    {
        text: "Magic is not a practice. It is a living, breathing web of energy that, with our permission, can encase our every action.",
        author: "Dorothy Morrison",
        category: "mystical"
    }
];