import { quotes } from './quotes.js';

// ===== DOM ELEMENTS =====
const quoteContent = document.querySelector('.quote-content');
const quoteAuthor = document.querySelector('.author-name');
const copyBtn = document.getElementById('copy-btn');
const themeBtn = document.getElementById('theme-btn');
const randomBtn = document.getElementById('random-btn');
const currentDate = document.getElementById('current-date');
const tooltip = document.getElementById('tooltip');
const body = document.body;

// ===== STATE MANAGEMENT =====
let currentTheme = localStorage.getItem('mystical-theme') || 'dark';
let isAnimating = false;
let currentQuoteIndex = 0;

// ===== INITIALIZATION =====
function init() {
    displayCurrentDate();
    displayDailyQuote();
    setupEventListeners();
    applyTheme();
    
    // Add entrance animations
    setTimeout(() => {
        document.querySelector('.site-header').style.animation = 'fade-in-up 1s ease forwards';
        document.querySelector('.quote-container').style.animation = 'fade-in-up 1.2s ease forwards';
        document.querySelector('.controls').style.animation = 'fade-in-up 1.4s ease forwards';
    }, 100);
}

// ===== DATE FUNCTIONS =====
function displayCurrentDate() {
    const now = new Date();
    const options = { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
    };
    
    const formattedDate = now.toLocaleDateString('en-US', options);
    currentDate.textContent = formattedDate;
    
    // Add floating animation to date
    currentDate.parentElement.style.animation = 'fade-in-up 1.6s ease forwards';
}

function getDayOfYear(date) {
    const start = new Date(date.getFullYear(), 0, 0);
    const diff = date - start;
    const oneDay = 1000 * 60 * 60 * 24;
    return Math.floor(diff / oneDay);
}

// ===== QUOTE FUNCTIONS =====
function displayDailyQuote() {
    const today = new Date();
    const dayOfYear = getDayOfYear(today);
    
    // Use day of year to select quote consistently
    currentQuoteIndex = dayOfYear % quotes.length;
    const dailyQuote = quotes[currentQuoteIndex];
    
    displayQuote(dailyQuote);
}

function displayRandomQuote() {
    if (isAnimating) return;
    
    // Get a different random quote
    let randomIndex;
    do {
        randomIndex = Math.floor(Math.random() * quotes.length);
    } while (randomIndex === currentQuoteIndex && quotes.length > 1);
    
    currentQuoteIndex = randomIndex;
    const randomQuote = quotes[currentQuoteIndex];
    
    displayQuote(randomQuote, true);
}

function displayQuote(quote, animate = false) {
    if (animate) {
        isAnimating = true;
        
        // Fade out current quote
        quoteContent.style.opacity = '0';
        quoteAuthor.style.opacity = '0';
        
        setTimeout(() => {
            // Update content
            quoteContent.textContent = quote.text;
            quoteAuthor.textContent = `— ${quote.author}`;
            
            // Fade in new quote
            setTimeout(() => {
                quoteContent.style.opacity = '1';
                quoteAuthor.style.opacity = '1';
                isAnimating = false;
            }, 100);
        }, 300);
    } else {
        // Initial load with loading state
        quoteContent.classList.add('loading');
        
        setTimeout(() => {
            quoteContent.textContent = quote.text;
            quoteAuthor.textContent = `— ${quote.author}`;
            quoteContent.classList.remove('loading');
            
            // Entrance animation
            quoteContent.style.opacity = '0';
            quoteAuthor.style.opacity = '0';
            
            setTimeout(() => {
                quoteContent.style.transition = 'opacity 0.8s ease';
                quoteAuthor.style.transition = 'opacity 0.8s ease 0.3s';
                quoteContent.style.opacity = '1';
                quoteAuthor.style.opacity = '1';
            }, 100);
        }, 800);
    }
}

// ===== CLIPBOARD FUNCTIONS =====
async function copyQuote() {
    const quote = quoteContent.textContent;
    const author = quoteAuthor.textContent;
    const textToCopy = `"${quote}" ${author}`;
    
    try {
        await navigator.clipboard.writeText(textToCopy);
        showCopyFeedback();
        showTooltip(copyBtn, 'Copied to spellbook! ✨');
    } catch (err) {
        fallbackCopyToClipboard(textToCopy);
    }
}

function fallbackCopyToClipboard(text) {
    const textArea = document.createElement('textarea');
    textArea.value = text;
    textArea.style.position = 'fixed';
    textArea.style.left = '-999999px';
    textArea.style.top = '-999999px';
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    
    try {
        document.execCommand('copy');
        showCopyFeedback();
        showTooltip(copyBtn, 'Copied to spellbook! ✨');
    } catch (err) {
        console.error('Fallback copy failed:', err);
        showTooltip(copyBtn, 'Copy failed - please try manually');
    }
    
    document.body.removeChild(textArea);
}

function showCopyFeedback() {
    const originalText = copyBtn.querySelector('.btn-text').textContent;
    const originalIcon = copyBtn.querySelector('.btn-icon');
    
    copyBtn.classList.add('success');
    copyBtn.querySelector('.btn-text').textContent = 'Copied!';
    
    // Change icon to check
    originalIcon.setAttribute('data-lucide', 'check');
    lucide.createIcons();
    
    setTimeout(() => {
        copyBtn.classList.remove('success');
        copyBtn.querySelector('.btn-text').textContent = originalText;
        originalIcon.setAttribute('data-lucide', 'copy');
        lucide.createIcons();
    }, 2000);
}

// ===== THEME FUNCTIONS =====
function toggleTheme() {
    currentTheme = currentTheme === 'dark' ? 'light' : 'dark';
    localStorage.setItem('mystical-theme', currentTheme);
    applyTheme();
}

function applyTheme() {
    const themeIcon = themeBtn.querySelector('.theme-icon');
    const themeText = themeBtn.querySelector('.btn-text');
    
    if (currentTheme === 'light') {
        body.classList.remove('dark-theme');
        body.classList.add('light-theme');
        themeIcon.setAttribute('data-lucide', 'sun');
        themeText.textContent = 'Light Realm';
        showTooltip(themeBtn, 'Switch to dark realm', false);
    } else {
        body.classList.remove('light-theme');
        body.classList.add('dark-theme');
        themeIcon.setAttribute('data-lucide', 'moon');
        themeText.textContent = 'Dark Realm';
        showTooltip(themeBtn, 'Switch to light realm', false);
    }
    
    // Recreate icons after changing data-lucide attributes
    lucide.createIcons();
}

// ===== TOOLTIP FUNCTIONS =====
function showTooltip(element, text, autoHide = true) {
    const rect = element.getBoundingClientRect();
    const tooltipRect = tooltip.getBoundingClientRect();
    
    tooltip.textContent = text;
    tooltip.style.left = `${rect.left + (rect.width / 2) - (tooltipRect.width / 2)}px`;
    tooltip.style.top = `${rect.top - tooltipRect.height - 10}px`;
    tooltip.classList.add('show');
    
    if (autoHide) {
        setTimeout(() => {
            tooltip.classList.remove('show');
        }, 2000);
    }
}

function hideTooltip() {
    tooltip.classList.remove('show');
}

// ===== EVENT LISTENERS =====
function setupEventListeners() {
    // Button clicks
    copyBtn.addEventListener('click', copyQuote);
    themeBtn.addEventListener('click', toggleTheme);
    randomBtn.addEventListener('click', displayRandomQuote);
    
    // Keyboard shortcuts
    document.addEventListener('keydown', (e) => {
        if (e.ctrlKey || e.metaKey) {
            switch(e.key.toLowerCase()) {
                case 'c':
                    e.preventDefault();
                    copyQuote();
                    break;
                case 't':
                    e.preventDefault();
                    toggleTheme();
                    break;
                case 'r':
                    e.preventDefault();
                    displayRandomQuote();
                    break;
            }
        }
        
        // Space bar for random quote
        if (e.code === 'Space' && !e.target.matches('input, textarea')) {
            e.preventDefault();
            displayRandomQuote();
        }
    });
    
    // Enhanced hover effects
    const quoteContainer = document.querySelector('.quote-container');
    let hoverTimeout;
    
    quoteContainer.addEventListener('mouseenter', () => {
        clearTimeout(hoverTimeout);
        quoteContainer.style.transform = 'translateY(-5px) scale(1.02)';
    });
    
    quoteContainer.addEventListener('mouseleave', () => {
        hoverTimeout = setTimeout(() => {
            quoteContainer.style.transform = 'translateY(0) scale(1)';
        }, 100);
    });
    
    // Button hover tooltips
    copyBtn.addEventListener('mouseenter', () => {
        showTooltip(copyBtn, 'Copy quote to your spellbook', false);
    });
    
    copyBtn.addEventListener('mouseleave', hideTooltip);
    
    themeBtn.addEventListener('mouseenter', () => {
        const tooltipText = currentTheme === 'dark' ? 'Switch to light realm' : 'Switch to dark realm';
        showTooltip(themeBtn, tooltipText, false);
    });
    
    themeBtn.addEventListener('mouseleave', hideTooltip);
    
    randomBtn.addEventListener('mouseenter', () => {
        showTooltip(randomBtn, 'Summon a random quote', false);
    });
    
    randomBtn.addEventListener('mouseleave', hideTooltip);
    
    // Touch support for mobile
    let touchStartY = 0;
    
    document.addEventListener('touchstart', (e) => {
        touchStartY = e.touches[0].clientY;
    });
    
    document.addEventListener('touchend', (e) => {
        const touchEndY = e.changedTouches[0].clientY;
        const diff = touchStartY - touchEndY;
        
        // Swipe up for random quote
        if (diff > 50) {
            displayRandomQuote();
        }
    });
}

// ===== UTILITY FUNCTIONS =====
function getQuoteByCategory(category) {
    return quotes.filter(quote => quote.category === category);
}

function getRandomQuoteByCategory(category) {
    const categoryQuotes = getQuoteByCategory(category);
    if (categoryQuotes.length === 0) return null;
    
    const randomIndex = Math.floor(Math.random() * categoryQuotes.length);
    return categoryQuotes[randomIndex];
}

// ===== EXPORT FOR CONSOLE ACCESS =====
window.MysticalQuotes = {
    displayRandomQuote,
    toggleTheme,
    copyQuote,
    getQuoteByCategory,
    getRandomQuoteByCategory,
    quotes
};

// ===== INITIALIZE APP =====
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}

// ===== PERFORMANCE OPTIMIZATION =====
// Preload next quote for smoother transitions
function preloadNextQuote() {
    const nextIndex = (currentQuoteIndex + 1) % quotes.length;
    const nextQuote = quotes[nextIndex];
    
    // Create invisible elements to trigger font loading
    const preloadDiv = document.createElement('div');
    preloadDiv.style.visibility = 'hidden';
    preloadDiv.style.position = 'absolute';
    preloadDiv.innerHTML = `
        <span style="font-family: var(--font-display)">${nextQuote.text}</span>
        <span style="font-family: var(--font-ui)">${nextQuote.author}</span>
    `;
    document.body.appendChild(preloadDiv);
    
    setTimeout(() => {
        document.body.removeChild(preloadDiv);
    }, 100);
}

// Preload after initial load
setTimeout(preloadNextQuote, 2000);