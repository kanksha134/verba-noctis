# ✨ One Quote a Day - Mystical Daily Wisdom ✨

A visually stunning, interactive website that delivers daily inspiration through carefully curated quotes with enchanting cosmic, witchy, and dark academia aesthetics. Experience the perfect blend of ancient mysticism and modern web design.

## 🌟 Features

### Core Functionality
- **📅 Daily Quote Rotation**: Displays one unique quote per day based on calendar date for consistency
- **🔮 Copy to Spellbook**: One-click copying of quotes to clipboard with mystical feedback
- **🌙 Theme Toggle**: Switch between Dark Realm (gothic/witchy) and Light Realm (parchment/academia)
- **✨ Random Quote**: Summon any quote instantly with smooth animations
- **⌨️ Keyboard Shortcuts**: `Ctrl/Cmd + C` (copy), `Ctrl/Cmd + T` (theme), `Ctrl/Cmd + R` (random), `Space` (random)

### Visual Magic
- **🌌 Floating Stars**: Animated twinkling stars that respond to theme changes
- **🔮 Mystical Elements**: Floating moon, crystal, candle, and scroll animations
- **✨ Smooth Transitions**: Elegant fade-ins, hover effects, and theme transitions
- **📜 Parchment Textures**: Subtle texture overlays in light theme for authentic feel
- **🎭 Responsive Design**: Beautiful on all devices from mobile to desktop

### Interactive Elements
- **💫 Hover Glows**: Buttons and quote container respond with magical glowing effects
- **🌟 Tooltip System**: Contextual tooltips with mystical messaging
- **📱 Touch Support**: Swipe gestures for mobile users
- **♿ Accessibility**: Screen reader friendly, keyboard navigation, reduced motion support

## 🎨 Design Themes

### 🌙 Dark Realm (Gothic/Witchy)
- Deep cosmic backgrounds with gradient overlays
- Golden accents mimicking candlelight and starlight
- Floating mystical elements and twinkling stars
- Rich purples and midnight blues
- Gothic serif typography

### ☀️ Light Realm (Parchment/Academia)
- Warm parchment and cream backgrounds
- Subtle texture overlays for authentic paper feel
- Rich browns and golden accents
- Academic serif fonts
- Minimized floating elements for focus

## 🚀 Quick Start

### Local Development
1. **Clone or Download** the repository
2. **Open** `index.html` in your web browser
3. **Enjoy** your daily dose of mystical wisdom!

### File Structure
```
mystical-quotes/
├── index.html          # Main HTML structure with semantic markup
├── style.css           # Comprehensive styling with CSS custom properties
├── script.js           # Interactive functionality and animations
├── quotes.js           # Curated collection of 70+ inspirational quotes
└── README.md           # This documentation
```

## 🌐 Deployment

This website is ready to deploy to any static hosting platform:

### GitHub Pages
1. Create a new repository on GitHub
2. Upload all project files
3. Go to Settings → Pages
4. Select source branch (usually `main`)
5. Your site will be live at `https://username.github.io/repository-name`

### Netlify
1. Create account at [netlify.com](https://netlify.com)
2. Drag and drop the project folder onto Netlify
3. Site goes live automatically with custom domain options

### Vercel
1. Create account at [vercel.com](https://vercel.com)
2. Import project from GitHub or upload files
3. Automatic deployment with edge optimization

## 🔧 Customization

### Adding New Quotes
Edit the `quotes.js` file to add new inspirational content:

```javascript
export const quotes = [
    {
        text: "Your mystical quote here...",
        author: "Author Name",
        category: "mystical" // mystical, literary, cosmic, wisdom, etc.
    },
    // Add more quotes...
];
```

### Modifying Themes
Customize colors and aesthetics in `style.css` using CSS custom properties:

```css
:root {
    /* Dark Theme Colors */
    --dark-bg-primary: #0a0a0f;
    --dark-accent-primary: #ffd700;
    
    /* Light Theme Colors */
    --light-bg-primary: #faf7f0;
    --light-accent-primary: #8b4513;
    
    /* Typography */
    --font-display: 'Playfair Display', Georgia, serif;
    --font-body: 'Cormorant Garamond', Georgia, serif;
}
```

### Changing Fonts
Update the Google Fonts link in `index.html` and modify font variables:

```html
<link href="https://fonts.googleapis.com/css2?family=Your-Font:wght@400;600&display=swap" rel="stylesheet">
```

### Adding New Animations
Create custom animations in the CSS:

```css
@keyframes your-animation {
    0% { transform: translateY(0); }
    50% { transform: translateY(-10px); }
    100% { transform: translateY(0); }
}
```

## 🎯 Advanced Features

### Quote Categories
Quotes are organized by categories for future filtering:
- `mystical` - Magical and spiritual wisdom
- `literary` - Famous literary quotes
- `cosmic` - Space and universe themed
- `wisdom` - Philosophical insights
- `courage` - Motivational and empowering
- And more...

### Console API
Access advanced features through the browser console:

```javascript
// Get quotes by category
MysticalQuotes.getQuoteByCategory('mystical');

// Get random quote from specific category
MysticalQuotes.getRandomQuoteByCategory('cosmic');

// Programmatically trigger functions
MysticalQuotes.displayRandomQuote();
MysticalQuotes.toggleTheme();
```

### Keyboard Shortcuts
- `Ctrl/Cmd + C` - Copy current quote
- `Ctrl/Cmd + T` - Toggle theme
- `Ctrl/Cmd + R` - Display random quote
- `Space` - Display random quote
- `Swipe Up` (mobile) - Display random quote

## 📱 Browser Support

- **Chrome** 60+ (Full support)
- **Firefox** 55+ (Full support)
- **Safari** 12+ (Full support)
- **Edge** 79+ (Full support)
- **Mobile browsers** (iOS Safari, Chrome Mobile)

## ♿ Accessibility Features

- **Semantic HTML** with proper heading hierarchy
- **ARIA labels** for screen readers
- **Keyboard navigation** support
- **High contrast mode** compatibility
- **Reduced motion** support for users with vestibular disorders
- **Focus indicators** for keyboard users
- **Color contrast** meeting WCAG guidelines

## 🔒 Privacy & Performance

### Privacy
- **No tracking** or analytics
- **No cookies** or external data collection
- **Local storage only** for theme preference
- **No internet required** after initial load

### Performance
- **Optimized animations** with CSS transforms
- **Efficient DOM manipulation** with minimal reflows
- **Font preloading** for smooth text rendering
- **Lazy loading** of non-critical elements
- **Compressed assets** for faster loading

## 🎨 Design Inspiration

This project draws inspiration from:
- **Dark Academia** aesthetic with rich textures and scholarly fonts
- **Witchy/Mystical** themes with cosmic elements and magical interactions
- **Minimalist Design** philosophy like zachlatta.com for clean, focused layouts
- **Interactive Storytelling** with smooth animations and engaging micro-interactions

## 🌟 Future Enhancements

Potential features for future versions:
- **Quote Collections** - Save favorite quotes
- **Social Sharing** - Share quotes on social media
- **Audio Narration** - Text-to-speech for quotes
- **Multiple Languages** - International quote collections
- **Custom Backgrounds** - User-uploaded background images
- **Quote Submission** - Community-contributed quotes
- **Daily Notifications** - Browser notifications for daily quotes
- **Quote Search** - Find quotes by keyword or author
- **Mood-Based Quotes** - Quotes based on selected mood
- **Quote History** - View previously displayed quotes

## 📚 Quote Sources

The curated collection includes wisdom from:
- **Philosophers** (Socrates, Aristotle, Camus)
- **Authors & Poets** (Oscar Wilde, Rumi, Tolkien)
- **Scientists** (Einstein, Carl Sagan, Newton)
- **Mystics & Spiritual Teachers** (Various traditions)
- **Modern Inspirational Figures** (Maya Angelou, Oprah)
- **Literary Characters** and anonymous wisdom

## 🤝 Contributing

Contributions are welcome! Please feel free to:
- Add new quotes to the collection
- Improve animations and visual effects
- Enhance accessibility features
- Fix bugs or optimize performance
- Suggest new features

## 📜 License

This project is open source and available under the MIT License. Free to use and modify for personal and commercial projects. Attribution appreciated but not required.

## 🙏 Acknowledgments

- **Google Fonts** for beautiful typography
- **Lucide Icons** for clean, consistent iconography
- **The Quote Contributors** - All the wise souls whose words inspire us daily
- **The Open Source Community** for tools and inspiration

---

*"Magic is believing in yourself. If you can do that, you can make anything happen."* - Johann Wolfgang von Goethe

**✨ May this mystical companion bring daily wisdom and inspiration to your journey ✨**